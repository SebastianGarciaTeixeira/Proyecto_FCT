package dominio;

import java.time.LocalDate;
import java.time.LocalTime;

public class Organizador extends Usuario {
	
	// El atributo:
	private String telefono;
	
	//
	public Organizador(String nombre, String email, String contrasenia,String telefono) {
		super(nombre, email, contrasenia);
		this.telefono = telefono;	
	}

	//Creamos los setters y los gettres
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	// El método organizarEvento, el cual recibe todos los datos necesarios del
	// constructor del Evento, e incluye un objeto de la clase Organizador, que se 
	// inserta en el constructor de Evento. Además, devuelve un Evento:
	public Evento organizarEvento(String nombre, String descripcion, LocalDate fecha, LocalTime hora, int duracion, String ubicacion,Categoria categoria) {
		Evento evento = new Evento(nombre, descripcion, fecha, hora, duracion, ubicacion, categoria, this);
		return evento;
	}

	// ToString:
	public String toString() {
		return "Organizador [telefono=" + telefono + "]";
	}

	
}