package dominio;

public class Usuario {
	
	// Los atributos:
	private String nombre;
	private String email;
	private String contrasenia;
	
	// El constructor, que recibe 3 Strings:
	public Usuario(String nombre ,String email, String contrasenia) {
		this.nombre= nombre;
		this.email=email;
		this.contrasenia= contrasenia;
	}

	// Getters y Setters:
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
	
	// El método inscribirEvento, que recibe un Evento.
	// Saca la colección de asistentes de ese evento y añade a 
	// ese usuario mediante el this.
	// Al principio puse que el método también recibiese un usuario, pero
	// después de fijé en que en el diagrama no lo recibía:
	public void inscribirEvento(Evento evento) {
		evento.getAsistentes().add(this);
		System.out.println("Usuario inscrito al evento: " + evento);
	}
	
	// El método cancelarInscripcion, el cual también recibe un 
	// Usuario, pero esta vez lo elimina de la lista de asistentes
	// del evento:
	public void cancelarInscripcion(Evento evento) {
		evento.getAsistentes().remove(this);
		System.out.println("Usuario desinscripto al evento: " + evento);
	}

	// ToString:
	public String toString() {
		return "Usuario [nombre=" + nombre + ", email=" + email + ", contrasenia=" + contrasenia + "]";
	}
	
}