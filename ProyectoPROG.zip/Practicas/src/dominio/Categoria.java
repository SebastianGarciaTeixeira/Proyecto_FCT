package dominio;

public class Categoria{
	
	//Establecemos los atributos pertinentes:
	private String nombre;
	private String descripcion;
	
	//Creamos el Constructor, que recibe dos Strings:
	public Categoria(String nombre, String descripcion) {
		this.nombre= nombre;
		this.descripcion = descripcion;
	}

	//Los Setters y Getters:
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	//To String
	
	public String toString() {
		return "Categoria [nombre=" + nombre + ", descripcion=" + descripcion + "]";
	}
	
	
}
