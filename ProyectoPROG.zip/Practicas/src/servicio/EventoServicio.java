package servicio;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;

import java.util.Scanner;

import dominio.Categoria;
import dominio.Evento;
import dominio.Organizador;
import dominio.Usuario;
import persistencia.CategoriaDao;
import persistencia.EventoDao;

// Implementamos la interfaz IEventoServicio:
public class EventoServicio implements IEventoServicio{
	
	// Atributos propios:
	// Scanner, EventoDao y CategoríaDao
	private final Scanner sc;
	private EventoDao eventoDao;
	private CategoriaDao categoriaDao;
	
	// Constructor, que inicia los anteriores atributos:
	public EventoServicio(Scanner sc) {
		this.sc = sc;
		this.eventoDao = new EventoDao();
		this.categoriaDao = new CategoriaDao();
	}

	// El método mostrarEventos, que mediante un for each, recorre 
	// todos los eventos que hay y los muestra por pantalla:
	@Override
	public void mostrarEventos() {
		for(Evento e:eventoDao.obtenerEventos().values()) {
			System.out.println(e);
		}
		
	}
	
	// El método mostrarEventosUsuario, el cual recibe un usuario.
	// Lo que hace el método principalmente es que obtiene los eventos,
	// uno a uno, y guarda la lista de participantes en un HashSet.
	// Después, busca al usuario introducido en ese HashSet.
	// Si lo encuentra, te muestra un mensaje informándote de a qué evento está inscrito.
	// Si no, te muestra que no está inscrito en ningún evento:
	@Override
	public void mostrarEventosUsuario(Usuario usuario) {
		
		for(Evento u:eventoDao.obtenerEventos().values()) {
			HashSet<Usuario> usuarios = u.getAsistentes();
			
			if(usuarios.contains(usuario)) {
				System.out.println("Ese usuario ya está inscrito en el evento: " + u.getNombre());
			} else {
				System.out.println("Ese usuario no está inscrito en ningún evento.");
			}
			
		}
		
	}

	// El método inscribirUsuario, el cual recibe un usuario.
	// Primero te pide al nombre del evento al cual lo quieres inscribir,
	// después, se saca el evento que tiene ese nombre.
	// Si el evento existe, se inscribe. Si no, se muestra en mensaje
	@Override
	public void inscribirUsuario(Usuario usuario) {
		
		System.out.println("Dime el nombre del evento al cual se quiere inscribir:");
		String nombreEvento = sc.nextLine();
		Evento evento = eventoDao.obtenerEventos().get(nombreEvento);
		
		if(evento != null) {
			usuario.inscribirEvento(evento);
			System.out.println("¡Inscrito!");
		}else {
			System.out.println("No se ha podido inscribir porque el evento no existe.");
		}
	}

	// Método cancelarInscripción, el cual funciona de manera muy 
	// similar al anterior, pero esta vez, elimina a un usuario de
	// la coleccion del evento mediante el método cancelarInscripcion:
	@Override
	public void cancelarInscripcion(Usuario usuario) {
		
		System.out.println("Dime el nombre del evento:");
		String nombreEvento = sc.nextLine();
		Evento evento = eventoDao.obtenerEventos().get(nombreEvento);
		
		if(evento != null) {
			usuario.cancelarInscripcion(evento);
			System.out.println("Se ha cancelado la inscripción.");
		}else {
			System.out.println("No se ha podido cancelar la inscripción porque el evento no existe.");
		}
	}
		
	
	// Método mostrarEventosOrganizador, el cual recibe un organizador.
	// Mediante un boolean controla si se encuentra el evento o no.
	// Recorre un for each para obtener eventos. Dentro de ese for each, si 
	// encuentra un evento cuyo organizador sea el introducido, muestra el evento,
	// si no, muestra un mensaje:
	@Override
	public void mostrarEventosOrganizador(Organizador organizador) {
	
		 boolean encontrado = false;
		
		for(Evento e:eventoDao.obtenerEventos().values()) {
			if(e.getOrganizador().equals(organizador)) {
				System.out.println(e);
				  encontrado = true;
			}
		}
		
		if (!encontrado) {
	        System.out.println("No hay ningún evento para este organizador.");
	    }
		
	}
	
	// Método crearEvento, el cual recibe un organizador.
	// Básicamente, pide los atributos necesarios para crear el evento.
	// Además, lo inserta mediante el Dao:
	@Override
	public void crearEvento(Organizador organizador) {
		
		System.out.println("Introduce el nombre:");
		String nombre = sc.nextLine();

		System.out.println("Introduce la descripción:");
		String descripcion = sc.nextLine();

		System.out.println("Introduce la fecha (formato YYYY-MM-DD):");
		LocalDate fecha = LocalDate.parse(sc.nextLine());

		System.out.println("Introduce la hora (formato HH:MM):");
		LocalTime hora = LocalTime.parse(sc.nextLine());

		System.out.println("Introduce la duración:");
		int duracion = Integer.parseInt(sc.nextLine());

		System.out.println("Introduce la ubicación:");
		String ubicacion = sc.nextLine();

		String nombreCategoria;
		Categoria categoria = null;
		
		// Un do while por si no encuentra la categoría:
		do {
			System.out.println("Introduce el nombre de la categoría:");
			nombreCategoria = sc.nextLine();
			
			if(categoriaDao.obtenerCategoria(nombreCategoria) != null) {
				categoria = categoriaDao.obtenerCategoria(nombreCategoria);
			}else {
				System.out.println("La categoría que estás buscando no existe, por favor vuelve a introducirla de nuevo:");
			}
			
		}while(nombreCategoria == null);
		
		eventoDao.insertarEvento(organizador.organizarEvento(nombre, descripcion, fecha, hora, duracion, ubicacion, categoria));
		System.out.println("Evento creado.");
		
		
	}

}