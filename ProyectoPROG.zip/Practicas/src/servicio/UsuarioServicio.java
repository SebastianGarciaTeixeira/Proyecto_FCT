package servicio;

import java.util.Scanner;


import dominio.Usuario;
import persistencia.UsuarioDao;

// Implementa la interfaz IUsuarioServicio:
public class UsuarioServicio implements IUsuarioServicio{
	
	// Atributos:
	private final Scanner sc;
	private UsuarioDao usuarioDao;
	
	// Constructor:
	public UsuarioServicio(Scanner sc) {
		this.sc = sc;
		this.usuarioDao = new UsuarioDao();
	}
	
	// Método hacerLogin, que funciona igual que el de organizador:
	@Override
	public Usuario hacerLogin() {
		
		System.out.println("Dame el nombre del usuario");
		String nombreUsuario = sc.nextLine();
		System.out.println("Dame el contraseña del usuario");
		String contraseniaUsuario = sc.nextLine();
		
		Usuario usuario = usuarioDao.login(nombreUsuario, contraseniaUsuario);
		return usuario;
	}
	
	// Método registrarUsuario, que funciona igual que el de organizador:
	@Override
	public void registrarUsuario() {
	
		System.out.println("Dame el nombre del usuario");
		String nombreUsuario = sc.nextLine();
		System.out.println("Dame el correo del usuario");
		String emailUsuario = sc.nextLine();
		System.out.println("Dame el contraseña del usuario");
		String contraseniaUsuario = sc.nextLine();
		
		Usuario usuario = new Usuario(nombreUsuario,emailUsuario,contraseniaUsuario);

		usuarioDao.registrar(usuario);
		
		
	}
	
}