package servicio;

import java.util.Scanner;

import dominio.Organizador;
import persistencia.OrganizadorDao;

// Se implementa la interfaz
public class OrganizadorServicio implements IOrganizadorServicio{
	
	// Atributos:
	private final Scanner sc;
	private OrganizadorDao organizadorDao;
	
	// Constructor:
	public OrganizadorServicio(Scanner sc) {
		this.sc = sc;
		this.organizadorDao = new OrganizadorDao();
	}
	
	// Método hacerLogin, que pide nombre y contraseña y
	// chequea si está correcto mediante el Dao.
	// Devuelve un organizador, que puede ser el que corresponde
	// o null si el nombre y la contraseña no existen:
	@Override
	public Organizador hacerLogin() {
		
		System.out.println("Introduce tu nombre");
		String nombreOrganizador = sc.nextLine();
		System.out.println("Introduce la contraseña");
		String contraseniaOrganizador = sc.nextLine();

		Organizador organizador = organizadorDao.login(nombreOrganizador, contraseniaOrganizador);
		return organizador;
	}
	
	// Método registrarOrganizador, el cual pide todos los atributos necesarios
	// para instanciar un orgnaizador. Se crea y se guarda mediante el Dao:
	@Override
	public void registrarOrganizador() {
		
		System.out.println("Dame el nombre del organizador");
		String nombreOrganizador = sc.nextLine();
		System.out.println("Dame el correo del organizador");
		String emailOrganizador = sc.nextLine();
		System.out.println("Dame el contraseña del organizador");
		String contraseniaOrganizador = sc.nextLine();
		System.out.println("Dame el telefono del organizador");
		String telefonoOrganizador = sc.nextLine();
		
		Organizador organizador = new Organizador(nombreOrganizador,emailOrganizador,contraseniaOrganizador,telefonoOrganizador);
		
		organizadorDao.registrar(organizador);
		
		
		
	}
	
}