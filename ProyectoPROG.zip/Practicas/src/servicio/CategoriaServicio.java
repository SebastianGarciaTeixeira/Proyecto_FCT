package servicio;

import java.util.Scanner;

import dominio.Categoria;
import persistencia.CategoriaDao;

//Implementamos la interfaz ICategoriaServicio:
public class CategoriaServicio implements ICategoriaServicio {
	
	// El Scanner y CategoriaDao como atributos:
	private final Scanner sc;
	private CategoriaDao categoriaDao;
	
	// El constructor, que inicia el Scanner y el categoriaDao:
	public CategoriaServicio(Scanner sc) {
		this.sc = sc;
		this.categoriaDao = new CategoriaDao();
	}
	
	// El método de la interfaz, en el cual te pide el nombre
	// de la categoría mediante el scanner.
	// Después, busca esa categoría en el Dao. Si la encuentra mediante
	// el nombre, te la devuelve. Si no la encuentra, devuelve null:
	@Override
	public Categoria buscarCategoria() {

	    System.out.println("Introduce el nombre de la categoría:");
	    String nombreCategoria = sc.nextLine();

	        if (categoriaDao.obtenerCategoria(nombreCategoria) != null) {
	            System.out.println("La categoria " + nombreCategoria + " es: " + categoriaDao.obtenerCategoria(nombreCategoria));
	            	return categoriaDao.obtenerCategoria(nombreCategoria);
	        }
	    
	    return null;
	}
}